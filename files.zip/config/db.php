<?php
// Kết nối database
$host = 'localhost';
$db   = 'hrm_crm';
$user = 'db_user';
$pass = 'db_pass';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
} catch (PDOException $e) {
    die("Kết nối database thất bại: " . $e->getMessage());
}