<?php
require_once "../app/Models/Employee.php";
require_once "../app/Middleware/AuthMiddleware.php";

class EmployeeController {
    public function index() {
        AuthMiddleware::checkLogin();
        // Chỉ Admin, HR Manager được quyền xem
        AuthMiddleware::checkRole(['Admin', 'HR Manager', 'Super Admin']);
        $employees = Employee::getByCompany($_SESSION['company_id']);
        include "../app/Views/employees.php";
    }

    public function create() {
        AuthMiddleware::checkLogin();
        AuthMiddleware::checkRole(['Admin', 'HR Manager', 'Super Admin']);
        // Xử lý thêm mới nhân viên...
    }
    // Sửa, xóa, tìm kiếm... tương tự
}