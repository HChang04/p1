<?php
require_once "../app/Models/Company.php";
require_once "../app/Middleware/AuthMiddleware.php";

class CompanyController {
    public function settings() {
        AuthMiddleware::checkLogin();
        // Chỉ Admin hoặc Super Admin mới xem/cấu hình công ty
        AuthMiddleware::checkRole(['Admin', 'Super Admin']);
        $company = Company::findById($_SESSION['company_id']);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Xử lý cập nhật tên, logo, thông báo hệ thống...
            $name = $_POST['name'];
            // Upload logo
            if (!empty($_FILES['logo']['name'])) {
                $logo = basename($_FILES['logo']['name']);
                move_uploaded_file($_FILES['logo']['tmp_name'], "uploads/logos/$logo");
            } else {
                $logo = $company['logo'];
            }
            Company::update($_SESSION['company_id'], [
                'name' => $name,
                'logo' => $logo
            ]);
            set_flash('success', 'Cập nhật thành công!');
            header("Location: index.php?page=company-settings");
            exit;
        }
        include "../app/Views/company-settings.php";
    }
}