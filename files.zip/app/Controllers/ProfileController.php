<?php
require_once "../app/Models/User.php";
require_once "../app/Middleware/AuthMiddleware.php";
require_once "../app/Helpers/functions.php";

class ProfileController {
    public function index() {
        AuthMiddleware::checkLogin();
        $user = User::findById($_SESSION['user_id']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Xử lý upload avatar
            if (!empty($_FILES['avatar']['name'])) {
                $fileName = uniqid() . '_' . basename($_FILES['avatar']['name']);
                $targetDir = "uploads/avatars/";
                if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
                $targetFile = $targetDir . $fileName;
                $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                if (in_array($_FILES['avatar']['type'], $allowedTypes)) {
                    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $targetFile)) {
                        User::updateAvatar($_SESSION['user_id'], $fileName);
                        $_SESSION['avatar'] = $fileName;
                        set_flash('success', 'Đã cập nhật ảnh đại diện!');
                    } else {
                        set_flash('danger', 'Không thể upload file!');
                    }
                } else {
                    set_flash('danger', 'Chỉ chấp nhận file ảnh JPG, PNG, GIF!');
                }
            }
            // Xử lý đổi mật khẩu
            if (!empty($_POST['new_password'])) {
                $newPass = $_POST['new_password'];
                if (strlen($newPass) < 6) {
                    set_flash('danger', 'Mật khẩu tối thiểu 6 ký tự');
                } else {
                    User::updatePassword($_SESSION['user_id'], $newPass);
                    set_flash('success', 'Đổi mật khẩu thành công!');
                }
            }
            header("Location: index.php?page=profile");
            exit;
        }

        include "../app/Views/profile.php";
    }
}