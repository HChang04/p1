<?php
require_once "../app/Middleware/AuthMiddleware.php";
class DashboardController {
    public function index() {
        AuthMiddleware::checkLogin();
        // Lấy dữ liệu KPI, biểu đồ...
        include "../app/Views/dashboard.php";
    }
}