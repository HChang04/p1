<?php
require_once "../app/Models/User.php";

class AuthController {
    // Hiển thị form login, xử lý đăng nhập
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'];
            $password = $_POST['password'];
            $user = User::findByEmail($email);

            if ($user && password_verify($password, $user['password'])) {
                // Tự động xác định tenant thông qua email
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['company_id'] = $user['company_id'];
                $_SESSION['role'] = $user['role'];
                header("Location: index.php");
                exit;
            } else {
                $error = "Sai tài khoản hoặc mật khẩu";
            }
        }
        include "../app/Views/auth/login.php";
    }

    // Hiển thị form đăng ký, xử lý đăng ký
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'];
            $domain = explode('@', $email)[1];
            // Tìm company theo domain, nếu chưa có thì tạo mới
            $company = Company::findOrCreateByDomain($domain);

            $data = [
                'email' => $email,
                'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                'company_id' => $company['id'],
                'role' => 'Employee',
                'position' => $_POST['position'] ?? null,
            ];
            User::create($data);
            header("Location: index.php?page=login");
            exit;
        }
        include "../app/Views/auth/register.php";
    }
}