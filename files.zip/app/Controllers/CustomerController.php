<?php
require_once "../app/Models/Customer.php";
require_once "../app/Middleware/AuthMiddleware.php";

class CustomerController {
    public function index() {
        AuthMiddleware::checkLogin();
        $customers = Customer::getByCompany($_SESSION['company_id']);
        include "../app/Views/customers.php";
    }
}