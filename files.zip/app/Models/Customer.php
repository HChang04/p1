<?php
require_once "../config/db.php";

class Customer {
    public static function getByCompany($company_id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM customers WHERE company_id = ?");
        $stmt->execute([$company_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}