<?php
require_once "../config/db.php";

class Company {
    public static function findById($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function update($id, $data) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE companies SET name = ?, logo = ? WHERE id = ?");
        $stmt->execute([$data['name'], $data['logo'], $id]);
    }
}