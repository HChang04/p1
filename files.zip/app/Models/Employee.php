<?php
require_once "../config/db.php";

class Employee {
    public static function getByCompany($company_id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM users WHERE company_id = ? AND role = 'Employee'");
        $stmt->execute([$company_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}