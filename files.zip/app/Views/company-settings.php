<?php include "layout/header.php"; ?>
<div class="container">
    <h4>Cấu hình công ty</h4>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-2">
            <label>Tên công ty</label>
            <input name="name" value="<?= $company['name'] ?>" class="form-control">
        </div>
        <div class="mb-2">
            <label>Logo</label><br>
            <img src="uploads/logos/<?= $company['logo'] ?? 'default.png' ?>" width="80"><br>
            <input type="file" name="logo" class="form-control">
        </div>
        <button class="btn btn-primary">Lưu</button>
    </form>
</div>
<?php include "layout/footer.php"; ?>