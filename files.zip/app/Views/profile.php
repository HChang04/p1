<?php include "layout/header.php"; ?>
<div class="container">
    <h4>Hồ sơ cá nhân</h4>
    <?php include "layout/toast.php"; ?>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Ảnh đại diện</label><br>
            <img src="uploads/avatars/<?= htmlspecialchars($user['avatar'] ?? 'default.png') ?>" width="80" class="rounded-circle mb-2"><br>
            <input type="file" name="avatar" class="form-control" accept="image/*">
        </div>
        <div class="mb-3">
            <label>Mật khẩu mới</label>
            <input type="password" name="new_password" class="form-control" minlength="6" placeholder="Để trống nếu không đổi">
        </div>
        <button class="btn btn-primary">Cập nhật</button>
    </form>
</div>
<?php include "layout/footer.php"; ?>