<?php include "layout/header.php"; ?>
<div class="container">
    <h4>Dashboard tổng hợp</h4>
    <div class="row">
        <div class="col-md-4">
            <div class="card text-bg-primary mb-3">
                <div class="card-body">
                    <h5 class="card-title">Tổng nhân viên</h5>
                    <p class="card-text" id="totalEmployees">0</p>
                </div>
            </div>
        </div>
        <!-- Thêm các box KPI khác -->
    </div>
    <canvas id="kpiChart"></canvas>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Demo Chart.js (bạn lấy data động từ PHP nếu muốn)
    const ctx = document.getElementById('kpiChart').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Nhân viên', 'Khách hàng'],
            datasets: [{
                label: 'Số lượng',
                data: [<?= $totalEmployees ?? 0 ?>, <?= $totalCustomers ?? 0 ?>],
                backgroundColor: ['#007bff','#28a745']
            }]
        }
    });
</script>
<?php include "layout/footer.php"; ?>