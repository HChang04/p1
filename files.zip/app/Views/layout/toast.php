<?php
$flashes = get_flash();
foreach ($flashes as $type => $messages) {
    foreach ($messages as $msg) {
        echo "<div class='toast align-items-center text-bg-$type border-0 show mb-2' role='alert' aria-live='assertive' aria-atomic='true'>
                <div class='d-flex'>
                    <div class='toast-body'>$msg</div>
                    <button type='button' class='btn-close btn-close-white me-2 m-auto' data-bs-dismiss='toast'></button>
                </div>
              </div>";
    }
}
?>