<?php include "layout/header.php"; ?>
<div class="container">
    <h4>Danh sách nhân viên</h4>
    <a href="index.php?page=employee-create" class="btn btn-success mb-2">Thêm nhân viên</a>
    <table class="table table-bordered">
        <thead>
            <tr><th>Avatar</th><th>Tên</th><th>Email</th><th>Phòng ban</th><th>Chức vụ</th><th>Hành động</th></tr>
        </thead>
        <tbody>
            <?php foreach ($employees as $e): ?>
            <tr>
                <td><img src="uploads/avatars/<?= $e['avatar'] ?? 'default.png' ?>" width="40" class="rounded-circle"></td>
                <td><?= $e['name'] ?? '' ?></td>
                <td><?= $e['email'] ?></td>
                <td><?= $e['department'] ?? '' ?></td>
                <td><?= $e['position'] ?? '' ?></td>
                <td>
                    <a href="index.php?page=employee-edit&id=<?= $e['id'] ?>" class="btn btn-warning btn-sm">Sửa</a>
                    <a href="index.php?page=employee-delete&id=<?= $e['id'] ?>" class="btn btn-danger btn-sm">Xóa</a>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>
<?php include "layout/footer.php"; ?>