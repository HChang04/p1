<?php include "layout/header.php"; ?>
<div class="container">
    <h4>Danh sách khách hàng</h4>
    <a href="index.php?page=customer-create" class="btn btn-success mb-2">Thêm khách hàng</a>
    <table class="table table-bordered">
        <thead>
            <tr><th>Tên khách</th><th>Email</th><th>Ghi chú</th><th>Phân loại</th><th>Hành động</th></tr>
        </thead>
        <tbody>
            <?php foreach ($customers as $c): ?>
            <tr>
                <td><?= $c['name'] ?></td>
                <td><?= $c['email'] ?></td>
                <td><?= $c['note'] ?></td>
                <td><?= $c['type'] ?></td>
                <td>
                    <a href="index.php?page=customer-edit&id=<?= $c['id'] ?>" class="btn btn-warning btn-sm">Sửa</a>
                    <a href="index.php?page=customer-delete&id=<?= $c['id'] ?>" class="btn btn-danger btn-sm">Xóa</a>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>
<?php include "layout/footer.php"; ?>