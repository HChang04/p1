<!DOCTYPE html>
<html lang="vi">
<head>
    <title>Đăng nhập HRM/CRM</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container">
        <h3 class="mt-5">Đăng nhập hệ thống</h3>
        <?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <form method="POST">
            <input name="email" type="email" class="form-control mb-2" placeholder="Email" required>
            <input name="password" type="password" class="form-control mb-2" placeholder="Mật khẩu" required>
            <button class="btn btn-primary">Đăng nhập</button>
        </form>
        <a href="index.php?page=register">Đăng ký</a> | 
        <a href="index.php?page=forgot-password">Quên mật khẩu?</a>
    </div>
</body>
</html>