<?php
// Hàm hiển thị thông báo toast
function set_flash($type, $message) {
    $_SESSION['flash'][$type][] = $message;
}

function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $flashes = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flashes;
    }
    return [];
}