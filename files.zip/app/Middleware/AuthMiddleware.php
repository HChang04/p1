<?php
// Middleware kiểm tra đăng nhập, phân quyền
class AuthMiddleware {
    public static function checkLogin() {
        if (empty($_SESSION['user_id'])) {
            header("Location: index.php?page=login");
            exit;
        }
    }

    public static function checkRole($roles = []) {
        if (empty($_SESSION['role']) || !in_array($_SESSION['role'], $roles)) {
            header("Location: index.php?page=dashboard&error=access_denied");
            exit;
        }
    }
}